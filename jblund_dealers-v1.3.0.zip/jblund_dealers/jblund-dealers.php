<?php
/**
 * Plugin Name: JBLund Dealers
 * Plugin URI: https://github.com/MacphersonDesigns/jblund_dealers
 * Description: A custom WordPress plugin to store and display dealer information for JBLund Dock's B2B Website
 * Version: 1.3.0
 * Author: Macpherson Designs
 * Author URI: https://github.com/MacphersonDesigns
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: jblund-dealers
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Start output buffering to prevent header warnings
ob_start();

// Define plugin constants
define('JBLUND_DEALERS_VERSION', '1.3.0');
define('JBLUND_DEALERS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('JBLUND_DEALERS_PLUGIN_URL', plugin_dir_url(__FILE__));

// Load Composer autoloader for TCPDF and other dependencies
if (file_exists(JBLUND_DEALERS_PLUGIN_DIR . 'vendor/autoload.php')) {
    require_once JBLUND_DEALERS_PLUGIN_DIR . 'vendor/autoload.php';
}

// Load core includes
require_once JBLUND_DEALERS_PLUGIN_DIR . 'includes/class-loader.php';
require_once JBLUND_DEALERS_PLUGIN_DIR . 'includes/class-plugin.php';
require_once JBLUND_DEALERS_PLUGIN_DIR . 'includes/class-activator.php';
require_once JBLUND_DEALERS_PLUGIN_DIR . 'includes/class-deactivator.php';
require_once JBLUND_DEALERS_PLUGIN_DIR . 'includes/helper-functions.php';

/**
 * Initialize the plugin
 */
function jblund_dealers_init() {
    // Load all module files
    $loader = new \JBLund\Includes\Loader(JBLUND_DEALERS_PLUGIN_DIR);
    $loader->load_modules();

    // Initialize plugin
    new \JBLund\Includes\Plugin();
}
add_action('plugins_loaded', 'jblund_dealers_init');

/**
 * Plugin activation hook
 */
function jblund_dealers_activate() {
    // Load necessary files for activation
    require_once JBLUND_DEALERS_PLUGIN_DIR . 'includes/class-loader.php';
    require_once JBLUND_DEALERS_PLUGIN_DIR . 'includes/class-activator.php';

    $loader = new \JBLund\Includes\Loader(JBLUND_DEALERS_PLUGIN_DIR);
    $loader->load_modules();

    \JBLund\Includes\Activator::activate();
}
register_activation_hook(__FILE__, 'jblund_dealers_activate');

/**
 * Plugin deactivation hook
 */
function jblund_dealers_deactivate() {
    \JBLund\Includes\Deactivator::deactivate();
}
register_deactivation_hook(__FILE__, 'jblund_dealers_deactivate');
